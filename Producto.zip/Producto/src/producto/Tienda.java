/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Tienda {
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<Producto> tienda = new ArrayList();
        
        
        int opcion;
        do{
            System.out.println("Que desea Realizar:");
            System.out.println("1. Cargar un producto");
            System.out.println("2. Comprar un Producto");
            System.out.println("3. Salir");
            opcion = scan.nextInt();
            switch (opcion){
                case 1 : tienda.add(new Producto()); break;
                case 2 : Compra.comprar();break;                
            }
            
        }
         
        while(opcion!=3);
    }
}
