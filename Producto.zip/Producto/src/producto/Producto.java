
package producto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Producto {
    Scanner scan = new Scanner(System.in);
    private String nombre = "";
    private double precio = 0;
    private int stock = 0;
    public Producto(Producto produc){
        this.nombre = produc.nombre;
        this.precio = produc.precio;
        this.stock = produc.stock;
    }
    public Producto(){
        ingresarNombre();
        ingresarPrecio();
        ingresarStock();        
        System.out.println("Producto Cargado"+"\n");
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getStock() {
        return stock;
    }
    
    public void ingresarNombre(){
        System.out.println("Ingrese Nombre del Producto");
        this.nombre = scan.next();
    }
    
    public void ingresarPrecio(){
        System.out.println("Ingrese Precio del Producto");
        this.precio = scan.nextDouble();
    }
    
    public void ingresarStock(){
        System.out.println("Ingrese Stock del Producto");
        this.stock = scan.nextInt();
    }
    @Override
    public String toString(){
        
        return "Nombre del producto: "+nombre+"\n"
                +"Precio: "+precio+"\n"
                +"Stock: "+stock;
    }
    
    public void actualizarStock(int valor){
        if ((stock-valor)>0){
            stock-=valor;
            System.out.println("Producto comprado");
        }else{
            System.out.println("No hay en stock esa cantidad de productos" +"\n"
                    + "stock de este producto:"+stock);
        }
    }
    
    
    
}
