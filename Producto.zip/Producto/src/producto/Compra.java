/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Compra {
        static Scanner scan = new Scanner(System.in);
        static List<Producto> tienda = new ArrayList();
       static Producto producto ;
        static int opcion;
        public Compra(){            
        }
        public static void comprar(){
            for(int i = 0;i<tienda.size();i++){
                System.out.print(i+". ");
                System.out.println(tienda.get(i));
            }
            System.out.print("Ingrese el numero de producto");
            producto = new Producto(tienda.get(scan.nextInt()));
            System.out.println("Cantidad que desea comprar?");
            producto.actualizarStock(scan.nextInt());
            
            
            
        }
        
        /*do{
            System.out.println("Que desea Realizar:");
            System.out.println("1. Cargar un producto");
            System.out.println("2. Comprar un Producto");
            System.out.println("3. Salir");
            opcion = scan.nextInt();
            switch (opcion){
                case 1 : tienda.add(new Producto()); break;
                case 2 : comprar();break;                
            }
            
        }while(opcion!=3);*/
    
}
